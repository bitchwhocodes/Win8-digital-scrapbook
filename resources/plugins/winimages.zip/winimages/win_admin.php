<?php


?>

<div class="win8admin">
	<div class="win8form">
		
		<p>Please enter the hex value of your background color (#000000).</p>
	    <input id="upload_color" type="text" size="36" name="color_image" /> 
	    <p>Enter a URL or upload an image. Please make sure the image is 150 x 150 </p>
	    <input id="upload_image" type="text" size="36" name="ad_image" value="http://" /> 
	    <input id="upload_image_button" class="button" type="button" value="Upload Image" />
	</div>

	<img class="chosen-image" src="" alt="Upload 150x150 image" width="150" height="150"/>
	<div>
		<a href="#" class="download"> Download Zip File </a>
	</div>
	<ul class='canvas-list'>
	</ul>
</div>
