<?php
/**
 * The template for displaying posts in the Image Post Format on index and archive pages
 *
 * Learn more: http://codex.wordpress.org/Post_Formats
 *
 * @package Mixfolio
 */
?>

<article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
	<header class="entry-header">
		<h1 class="entry-title">
			<?php the_title(); ?>
		</h1><!-- .entry-title -->
	</header><!-- .entry-header -->

	<div class="entry-content">

	<ul class="tabs-content">
		<li id="simple1tab" class="active">
			<?php the_post_thumbnail( 'large' ); ?>
			<?php mixfolio_posted_on(); ?>
		</li>
	</ul>

	</div><!-- .entry-content -->
</article><!-- #post-<?php the_ID(); ?> -->